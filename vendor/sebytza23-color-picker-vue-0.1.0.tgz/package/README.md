# @sebytza23/color-picker-vue

Install only this adapter and its core dependencies.

`npm install @sebytza23/color-picker-vue`

Documentation: https://sebytza23.github.io/color-picker/docs.html

Browser scripts are in browser/ for vanilla HTML and PHP; no framework is required.
