// packages/color-picker/vanilla/elements.ts
import {
  bindMarkerWheel,
  markerWheelStyle,
  markerStyle,
  bindAlphaInput,
  sliderValue,
  setSliderValue,
  alphaTrackStyle,
  channelSpecs,
  channelValue,
  setColorChannel,
  colorFormats,
  subscribeColor,
  parseColor,
  formatColor,
  createColorStore,
  bindColorArea,
  areaStyle,
  wheelStyle,
  wheelThumbStyle,
  thumbStyle
} from '@sebytza23/color-picker';
var ColorProviderElement = class extends HTMLElement {
  static {
    this.observedAttributes = ["disabled"];
  }
  attributeChangedCallback() {
    if (this.store) this.store.setDisabled(this.hasAttribute("disabled"));
  }
  setStore(store) {
    this.unsubscribe?.();
    this.unsubscribe = void 0;
    this.store = store;
    if (this.isConnected) this.connectedCallback();
  }
  connectedCallback() {
    if (this.unsubscribe) return;
    this.store ??= createColorStore(
      this.getAttribute("value") ?? "#6366F1",
      "hex",
      this.getAttribute("view") ?? "area",
      this.hasAttribute("disabled")
    );
    if (this.hasAttribute("disabled")) this.store.setDisabled(true);
    const updateDisabled = () => {
      const disabled = this.store.getSnapshot().disabled;
      this.toggleAttribute("inert", disabled);
      this.setAttribute("aria-disabled", String(disabled));
      this.dataset.disabled = String(disabled);
      this.querySelectorAll("input, select, button").forEach((control) => {
        if (control.closest("cp-provider") !== this) return;
        if (disabled) {
          if (!control.disabled) {
            control.dataset.cpDisabled = "";
            control.disabled = true;
          }
        } else if (control.hasAttribute("data-cp-disabled")) {
          control.disabled = false;
          delete control.dataset.cpDisabled;
        }
      });
    };
    let previousDisabled = this.store.getSnapshot().disabled;
    const states = this.store.subscribe(() => {
      const disabled = this.store.getSnapshot().disabled;
      if (disabled !== previousDisabled) {
        previousDisabled = disabled;
        updateDisabled();
      }
    });
    const observer = new this.ownerDocument.defaultView.MutationObserver(
      updateDisabled
    );
    observer.observe(this, { childList: true, subtree: true });
    updateDisabled();
    const colors = subscribeColor(
      this.store,
      () => this.dispatchEvent(
        new CustomEvent("color-change", {
          detail: this.store.getSnapshot().value,
          bubbles: true
        })
      )
    );
    this.unsubscribe = () => {
      states();
      colors();
      observer.disconnect();
    };
    this.dispatchEvent(new Event("color-context"));
  }
  disconnectedCallback() {
    this.unsubscribe?.();
    this.unsubscribe = void 0;
  }
};
function connect(element, render, bind) {
  const root = element.closest("cp-provider");
  if (!root) throw new Error("Color components require cp-provider");
  let unsubscribe, cleanup;
  const setup = () => {
    if (!root.store) return;
    unsubscribe?.();
    cleanup?.();
    render(root.store);
    unsubscribe = root.store.subscribe(() => render(root.store));
    cleanup = bind?.(root.store);
  };
  root.addEventListener("color-context", setup);
  setup();
  return () => {
    root.removeEventListener("color-context", setup);
    unsubscribe?.();
    cleanup?.();
  };
}
var ColorAreaElement = class extends HTMLElement {
  connectedCallback() {
    const area = this.querySelector("[data-area]"), thumb = area.firstElementChild;
    this.cleanup = connect(
      this,
      (store) => {
        const state = store.getSnapshot();
        area.style.cssText = `${areaStyle(state)};${area.dataset.customStyle ?? ""}`;
        thumb.style.cssText = thumbStyle(state);
        area.setAttribute(
          "aria-label",
          `Saturation and brightness. Arrow keys adjust; Shift for larger steps. ${Math.round(state.s)}% saturation, ${Math.round(state.v)}% brightness.`
        );
      },
      (store) => bindColorArea(area, store)
    );
  }
  disconnectedCallback() {
    this.cleanup?.();
  }
};
var ColorWheelElement = class extends HTMLElement {
  setMarkers(markers, activeId) {
    this.markers = markers;
    this.activeId = activeId;
    this.render();
  }
  render() {
    const area = this.querySelector("[data-area]");
    if (!area) return;
    const store = this.closest("cp-provider")?.store;
    if (!store) return;
    const classes = JSON.parse(
      this.getAttribute("data-classes") ?? "{}"
    );
    area.style.cssText = (this.markers ? markerWheelStyle() : wheelStyle(store.getSnapshot())) + ";" + (this.getAttribute("data-custom-style") ?? "");
    if (this.markers) {
      for (const el of area.querySelectorAll("[data-marker-id]"))
        el.hidden = !this.markers.some(
          (marker) => marker.id === el.dataset.markerId
        );
      for (const marker of this.markers) {
        let button = Array.from(
          area.querySelectorAll("[data-marker-id]")
        ).find((el) => el.dataset.markerId === marker.id);
        if (!button) {
          button = area.ownerDocument.createElement("button");
          button.type = "button";
          button.dataset.markerId = marker.id;
          button.dataset.cpPart = "marker";
          button.append(area.ownerDocument.createElement("span"));
          area.append(button);
        }
        button.hidden = false;
        button.className = "cp-wheel-marker " + (classes.marker ?? "");
        button.setAttribute(
          "aria-label",
          marker.ariaLabel ?? `Select ${marker.id} marker`
        );
        button.setAttribute(
          "aria-pressed",
          String(marker.id === this.activeId)
        );
        button.dataset.small = String(
          this.markers.length === 1 || !marker.label
        );
        button.style.cssText = markerStyle(marker, marker.id === this.activeId);
        const text = button.firstElementChild;
        text.dataset.cpPart = "marker-text";
        text.className = classes.text ?? "";
        text.textContent = marker.label ?? "";
      }
    } else {
      const thumb = area.querySelector('[data-cp-part="thumb"]');
      if (thumb) thumb.style.cssText = wheelThumbStyle(store.getSnapshot());
    }
  }
  connectedCallback() {
    this.markers = this.markers ?? (this.hasAttribute("data-markers") ? JSON.parse(this.getAttribute("data-markers")) : void 0);
    this.activeId ??= this.getAttribute("data-active-id") ?? void 0;
    const area = this.querySelector("[data-area]");
    this.cleanup = connect(
      this,
      () => this.render(),
      (store) => this.markers ? bindMarkerWheel(area, {
        getMarkers: () => this.markers ?? [],
        getActiveId: () => this.activeId ?? this.markers?.[0]?.id ?? "",
        select: (id) => this.dispatchEvent(
          new CustomEvent("marker-select", {
            detail: id,
            bubbles: true
          })
        ),
        setHSV: (id, hsv) => this.dispatchEvent(
          new CustomEvent("marker-change", {
            detail: { id, hsv },
            bubbles: true
          })
        )
      }) : bindColorArea(area, store, "wheel")
    );
  }
  disconnectedCallback() {
    this.cleanup?.();
  }
};
var ColorSliderElement = class extends HTMLElement {
  connectedCallback() {
    const input = this.querySelector("input"), channel = this.getAttribute("channel") ?? "h";
    this.cleanup = connect(
      this,
      (store) => {
        input.value = String(sliderValue(store.getSnapshot(), channel));
        input.parentElement.style.cssText = alphaTrackStyle(
          store.getSnapshot().hex
        );
      },
      (store) => {
        const update = () => setSliderValue(store, channel, Number(input.value));
        input.addEventListener("input", update);
        return () => input.removeEventListener("input", update);
      }
    );
  }
  disconnectedCallback() {
    this.cleanup?.();
  }
};
function applyFieldClasses(element) {
  const source = element.hasAttribute("data-classes") ? element : element.closest("cp-input[data-classes]");
  const classes = JSON.parse(source?.dataset.classes ?? "{}");
  const add = (node, value) => {
    if (node && value?.trim()) node.classList.add(...value.trim().split(/\s+/));
  };
  add(
    element.querySelector("label"),
    [classes.root, classes.label].filter(Boolean).join(" ")
  );
  const input = element.querySelector("input");
  if (input) {
    input.dataset.cpPart = "input";
    add(input, classes.input);
  }
  add(
    element.querySelector("[data-label], [data-channel-label]"),
    classes.text
  );
}
var ColorTextInputElement = class extends HTMLElement {
  connectedCallback() {
    applyFieldClasses(this);
    const input = this.querySelector("input"), label = this.querySelector("[data-label]");
    const format = (store) => this.getAttribute("format") ?? store.getSnapshot().format;
    this.cleanup = connect(
      this,
      (store) => {
        const f = format(store);
        input.maxLength = f === "hex" ? 9 : 64;
        if (input.ownerDocument.activeElement !== input)
          input.value = formatColor(
            store.getSnapshot().hex,
            f,
            store.getSnapshot().alpha
          );
        label.textContent = this.getAttribute("label") ?? f.toUpperCase();
        input.setAttribute("aria-invalid", "false");
      },
      (store) => {
        const update = () => {
          try {
            store.setHex(parseColor(input.value, format(store)));
            input.setAttribute("aria-invalid", "false");
          } catch {
            input.setAttribute("aria-invalid", "true");
          }
        };
        const reset = () => {
          input.value = formatColor(
            store.getSnapshot().hex,
            format(store),
            store.getSnapshot().alpha
          );
          input.setAttribute("aria-invalid", "false");
        };
        const key = (event) => {
          if (event.key === "Enter") reset();
        };
        input.addEventListener("input", update);
        input.addEventListener("blur", reset);
        input.addEventListener("keydown", key);
        return () => {
          input.removeEventListener("input", update);
          input.removeEventListener("blur", reset);
          input.removeEventListener("keydown", key);
        };
      }
    );
  }
  disconnectedCallback() {
    this.cleanup?.();
  }
};
var ColorChannelInputElement = class extends HTMLElement {
  connectedCallback() {
    const format = this.getAttribute("format"), index = Number(this.getAttribute("index")), spec = channelSpecs[format][index];
    if (!this.querySelector("input")) {
      this.innerHTML = '<label class="cp-channel"><span data-channel-label></span><span class="cp-channel-field"><input type="number"/><span data-unit aria-hidden="true"></span></span></label>';
    }
    applyFieldClasses(this);
    const input = this.querySelector("input");
    this.querySelector("[data-channel-label]").textContent = spec.label;
    this.querySelector("[data-unit]").textContent = spec.unit;
    input.setAttribute("aria-label", `${format.toUpperCase()} ${spec.label}`);
    input.min = String(spec.min);
    input.max = String(spec.max);
    input.step = String(spec.step);
    this.cleanup = connect(
      this,
      (store) => {
        if (input.ownerDocument.activeElement !== input)
          input.value = channelValue(store.getSnapshot(), format, index);
      },
      (store) => {
        const change = () => {
          try {
            if (!input.value.trim()) throw new Error("Incomplete");
            setColorChannel(store, format, index, Number(input.value));
            input.setAttribute("aria-invalid", "false");
          } catch {
            input.setAttribute("aria-invalid", "true");
          }
        };
        const reset = () => {
          input.value = channelValue(store.getSnapshot(), format, index);
          input.setAttribute("aria-invalid", "false");
        };
        const key = (event) => {
          if (event.key === "Enter") reset();
        };
        input.addEventListener("input", change);
        input.addEventListener("blur", reset);
        input.addEventListener("keydown", key);
        return () => {
          input.removeEventListener("input", change);
          input.removeEventListener("blur", reset);
          input.removeEventListener("keydown", key);
        };
      }
    );
  }
  disconnectedCallback() {
    this.cleanup?.();
  }
};
var ColorPreviewElement = class extends HTMLElement {
  connectedCallback() {
    const output = this.querySelector("output");
    this.cleanup = connect(this, (store) => {
      const value = store.getSnapshot().value;
      output.style.background = value;
      output.textContent = value;
      output.setAttribute("aria-label", `Selected color ${value}`);
    });
  }
  disconnectedCallback() {
    this.cleanup?.();
  }
};
var ColorInputElement = class extends HTMLElement {
  connectedCallback() {
    this.cleanup = connect(this, (store) => {
      const format = this.getAttribute("format") ?? store.getSnapshot().format;
      if (this.dataset.renderedFormat === format) return;
      this.dataset.renderedFormat = format;
      if (format === "hex") {
        const text = this.ownerDocument.createElement("cp-text-input");
        text.setAttribute("format", "hex");
        if (this.hasAttribute("label"))
          text.setAttribute("label", this.getAttribute("label"));
        text.innerHTML = '<label class="cp-input"><span data-label>HEX</span><input spellcheck="false" maxlength="9"/></label>';
        this.replaceChildren(text);
      } else {
        const group = this.ownerDocument.createElement("div");
        group.className = "cp-channels";
        group.setAttribute("role", "group");
        group.setAttribute(
          "aria-label",
          this.getAttribute("label") ?? format.toUpperCase()
        );
        for (let index = 0; index < 3; index++) {
          const channel = this.ownerDocument.createElement("cp-channel-input");
          channel.setAttribute("format", format);
          channel.setAttribute("index", String(index));
          group.append(channel);
        }
        this.replaceChildren(group);
      }
    });
  }
  disconnectedCallback() {
    this.cleanup?.();
  }
};
var ColorModeElement = class extends HTMLElement {
  connectedCallback() {
    const button = this.querySelector("button");
    const custom = this.hasAttribute("data-custom");
    this.cleanup = connect(
      this,
      (store) => {
        const format = store.getSnapshot().format;
        if (!custom) button.textContent = `${format.toUpperCase()} \u2194`;
        button.querySelectorAll("[data-color-format]").forEach((label) => label.textContent = format.toUpperCase());
        button.setAttribute(
          "aria-label",
          `Next color format (${format.toUpperCase()})`
        );
      },
      (store) => {
        const click = () => store.setFormat(
          colorFormats[(colorFormats.indexOf(store.getSnapshot().format) + 1) % colorFormats.length]
        );
        button.addEventListener("click", click);
        return () => button.removeEventListener("click", click);
      }
    );
  }
  disconnectedCallback() {
    this.cleanup?.();
  }
};
var ColorFormatSelectElement = class extends HTMLElement {
  connectedCallback() {
    const select = this.querySelector("select");
    this.cleanup = connect(
      this,
      (store) => {
        select.value = store.getSnapshot().format;
      },
      (store) => {
        const change = () => store.setFormat(select.value);
        select.addEventListener("change", change);
        return () => select.removeEventListener("change", change);
      }
    );
  }
  disconnectedCallback() {
    this.cleanup?.();
  }
};
var ColorViewSelectElement = class extends HTMLElement {
  connectedCallback() {
    const select = this.querySelector("select");
    this.cleanup = connect(
      this,
      (store) => {
        select.value = store.getSnapshot().view;
      },
      (store) => {
        const change = () => store.setView(select.value);
        select.addEventListener("change", change);
        return () => select.removeEventListener("change", change);
      }
    );
  }
  disconnectedCallback() {
    this.cleanup?.();
  }
};
var ColorSurfaceElement = class extends HTMLElement {
  connectedCallback() {
    this.cleanup = connect(this, (store) => {
      for (const child of this.children) {
        child.hidden = child.dataset.view !== store.getSnapshot().view;
      }
    });
  }
  disconnectedCallback() {
    this.cleanup?.();
  }
};
var ColorSwatchElement = class extends HTMLElement {
  connectedCallback() {
    const button = this.querySelector("button");
    this.cleanup = connect(
      this,
      () => {
      },
      (store) => {
        const click = () => store.setHex(this.getAttribute("value"));
        button.addEventListener("click", click);
        return () => button.removeEventListener("click", click);
      }
    );
  }
  disconnectedCallback() {
    this.cleanup?.();
  }
};
var ColorAlphaInputElement = class extends HTMLElement {
  connectedCallback() {
    this.cleanup = connect(
      this,
      () => {
      },
      (store) => bindAlphaInput(this.querySelector("input"), store)
    );
  }
  disconnectedCallback() {
    this.cleanup?.();
  }
};
var ColorOutputElement = class extends HTMLElement {
  connectedCallback() {
    this.cleanup = connect(this, (store) => {
      this.color = store.getColor();
      const target = this.querySelector("output");
      const format = this.getAttribute("format");
      if (target)
        target.textContent = format === "name" ? this.color.name : format === "json" ? JSON.stringify(this.color, null, 2) : store.getSnapshot().value;
      this.dispatchEvent(
        new CustomEvent("color-values", { detail: this.color, bubbles: true })
      );
    });
  }
  disconnectedCallback() {
    this.cleanup?.();
    this.cleanup = void 0;
  }
};
for (const [name, element] of [
  ["cp-provider", ColorProviderElement],
  ["cp-output", ColorOutputElement],
  ["cp-area", ColorAreaElement],
  ["cp-preview", ColorPreviewElement],
  ["cp-wheel", ColorWheelElement],
  ["cp-slider", ColorSliderElement],
  ["cp-alpha-input", ColorAlphaInputElement],
  ["cp-input", ColorInputElement],
  ["cp-text-input", ColorTextInputElement],
  ["cp-channel-input", ColorChannelInputElement],
  ["cp-mode", ColorModeElement],
  ["cp-format-select", ColorFormatSelectElement],
  ["cp-view-select", ColorViewSelectElement],
  ["cp-surface", ColorSurfaceElement],
  ["cp-swatch", ColorSwatchElement]
])
  if (!customElements.get(name)) customElements.define(name, element);

// packages/color-picker/vanilla/index.ts
export * from '@sebytza23/color-picker';
import {
  createColorStore as createColorStore2
} from '@sebytza23/color-picker';
var colorAreaMarkup = `<cp-area><div class="cp-area" data-area data-cp-part="surface" role="group" tabindex="0" aria-label="Saturation and brightness"><span data-cp-part="thumb" aria-hidden="true"></span></div></cp-area>`;
var colorWheelMarkup = `<cp-wheel><div class="cp-wheel" data-area data-cp-part="surface" role="group" tabindex="0" aria-label="Hue and saturation wheel"><span data-cp-part="thumb" aria-hidden="true"></span></div></cp-wheel>`;
var colorFormatMarkup = `<cp-format-select><label class="cp-format">Color format<select>${["hex", "rgb", "hsl", "hsv", "oklch", "oklab"].map((f) => `<option value="${f}">${f.toUpperCase()}</option>`).join("")}</select></label></cp-format-select>`;
function colorSliderMarkup(channel, label = channel) {
  const text = label.replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
  );
  return `<cp-slider channel="${channel}"><label class="cp-slider" data-channel="${channel}">${text}<input type="range" min="0" max="${channel === "h" ? 359 : 100}" step="1" /></label></cp-slider>`;
}
var colorPickerMarkup = `<div class="cp-picker">
  <cp-view-select><label class="cp-format">Picker view<select><option value="area">Rectangle</option><option value="wheel">Wheel</option></select></label></cp-view-select>
  <cp-surface><div data-view="area">${colorAreaMarkup}</div><div data-view="wheel">${colorWheelMarkup}</div></cp-surface>
  ${colorSliderMarkup("h", "Hue")}${colorSliderMarkup("v", "Brightness")}${colorSliderMarkup("alpha", "Alpha")}
  ${colorFormatMarkup}<cp-input></cp-input>
  <cp-alpha-input><label class="cp-channel">Alpha %<input type="number" min="0" max="100" step=".1" /></label></cp-alpha-input>
  <cp-mode><button type="button">Switch format</button></cp-mode>
  <cp-output format="name"><output aria-live="polite"></output></cp-output>
</div>`;
function mountColorPicker(host, options = {}) {
  const store = options.store ?? createColorStore2(
    options.value,
    options.format,
    options.view,
    options.disabled
  );
  const provider = host.ownerDocument.createElement(
    "cp-provider"
  );
  provider.className = options.className ?? "";
  if (options.disabled !== void 0) store.setDisabled(options.disabled);
  provider.setStore(store);
  provider.innerHTML = colorPickerMarkup;
  const change = () => options.onChange?.(store.getColor());
  provider.addEventListener("color-change", change);
  host.append(provider);
  change();
  return {
    element: provider,
    store,
    getColor: store.getColor,
    getValue: store.getValue,
    destroy() {
      provider.removeEventListener("color-change", change);
      provider.remove();
    }
  };
}
export {
  ColorOutputElement,
  ColorProviderElement,
  ColorWheelElement,
  colorAreaMarkup,
  colorFormatMarkup,
  colorPickerMarkup,
  colorSliderMarkup,
  colorWheelMarkup,
  mountColorPicker
};
//# sourceMappingURL=index.js.map
