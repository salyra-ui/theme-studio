import { type ColorMarker, type ColorStore } from '@sebytza23/color-picker';
export declare class ColorProviderElement extends HTMLElement {
    store?: ColorStore;
    private unsubscribe?;
    setStore(store: ColorStore): void;
    connectedCallback(): void;
    disconnectedCallback(): void;
}
export declare class ColorWheelElement extends HTMLElement {
    private cleanup?;
    private markers?;
    private activeId?;
    setMarkers(markers: readonly ColorMarker[], activeId: string): void;
    private render;
    connectedCallback(): void;
    disconnectedCallback(): void;
}
export declare class ColorOutputElement extends HTMLElement {
    color?: import('@sebytza23/color-picker').ColorInfo;
    private cleanup?;
    connectedCallback(): void;
    disconnectedCallback(): void;
}
