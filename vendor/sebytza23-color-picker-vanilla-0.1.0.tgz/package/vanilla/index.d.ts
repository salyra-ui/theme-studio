export * from './elements.js';
export * from '@sebytza23/color-picker';
import { type ColorStore, type ColorView, type ColorFormat, type ColorInfo } from '@sebytza23/color-picker';
import type { ColorProviderElement } from './elements.js';
export interface ColorPickerOptions {
    disabled?: boolean;
    value?: string;
    view?: ColorView;
    format?: ColorFormat;
    store?: ColorStore;
    className?: string;
    onChange?: (color: ColorInfo) => void;
}
/** Composable HTML parts can also be placed directly under cp-provider. */
export declare const colorAreaMarkup = "<cp-area><div class=\"cp-area\" data-area data-cp-part=\"surface\" role=\"group\" tabindex=\"0\" aria-label=\"Saturation and brightness\"><span data-cp-part=\"thumb\" aria-hidden=\"true\"></span></div></cp-area>";
export declare const colorWheelMarkup = "<cp-wheel><div class=\"cp-wheel\" data-area data-cp-part=\"surface\" role=\"group\" tabindex=\"0\" aria-label=\"Hue and saturation wheel\"><span data-cp-part=\"thumb\" aria-hidden=\"true\"></span></div></cp-wheel>";
export declare const colorFormatMarkup: string;
export declare function colorSliderMarkup(channel: 'h' | 's' | 'v' | 'alpha', label?: string): string;
export declare const colorPickerMarkup: string;
/** Mount one picker; destroy before reusing the same host with a different mount. */
export declare function mountColorPicker(host: HTMLElement, options?: ColorPickerOptions): {
    element: ColorProviderElement;
    store: ColorStore;
    getColor: () => ColorInfo;
    getValue: <F extends ColorFormat>(format: F) => import("@sebytza23/color-picker-react").ColorValues[F];
    destroy(): void;
};
