import { EventEmitter, ElementRef, type OnInit, type OnChanges } from '@angular/core';
import { type ColorView, markerStyle, type ColorMarker, type ColorPartClasses, type SliderChannel, type HSV, type ChannelFormat, type ChannelIndex, type ColorFormat, areaStyle, wheelStyle, wheelThumbStyle, thumbStyle, type ColorStore } from '@sebytza23/color-picker';
import * as i0 from "@angular/core";
export * from '@sebytza23/color-picker';
export declare class ColorContext {
    private current;
    private listeners;
    private forward;
    private unsubscribe;
    readonly store: ColorStore;
    constructor();
    configure(store: ColorStore): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorContext, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ColorContext>;
}
export declare function useColorStore(): ColorStore;
export declare function useColor(): import("@angular/core").Signal<import("@sebytza23/color-picker-angular").ColorSnapshot>;
export declare class ColorProvider implements OnInit, OnChanges {
    value?: string;
    view: ColorView;
    store?: ColorStore;
    colorChange: EventEmitter<string>;
    private context;
    private destroyRef;
    ngOnInit(): void;
    ngOnChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorProvider, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColorProvider, "cp-provider", never, { "value": { "alias": "value"; "required": false; }; "view": { "alias": "view"; "required": false; }; "store": { "alias": "store"; "required": false; }; }, { "colorChange": "colorChange"; }, never, ["*"], true, never>;
}
export declare class ColorArea {
    classes: ColorPartClasses;
    className: string;
    thumbText: string;
    label: string;
    area: ElementRef<HTMLElement>;
    readonly store: ColorStore;
    readonly state: import("@angular/core").Signal<import("@sebytza23/color-picker-angular").ColorSnapshot>;
    readonly areaStyle: typeof areaStyle;
    readonly thumbStyle: typeof thumbStyle;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorArea, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColorArea, "cp-area", never, { "classes": { "alias": "classes"; "required": false; }; "className": { "alias": "className"; "required": false; }; "thumbText": { "alias": "thumbText"; "required": false; }; "label": { "alias": "label"; "required": false; }; }, {}, never, ["[cpThumb]"], true, never>;
}
export declare class ColorWheel {
    label: string;
    className: string;
    classes: ColorPartClasses;
    thumbText: string;
    markers?: readonly ColorMarker[];
    activeId?: string;
    markerSelect: EventEmitter<string>;
    markerChange: EventEmitter<{
        id: string;
        hsv: Partial<HSV>;
    }>;
    area: ElementRef<HTMLElement>;
    readonly store: ColorStore;
    readonly state: import("@angular/core").Signal<import("@sebytza23/color-picker-angular").ColorSnapshot>;
    readonly wheelStyle: typeof wheelStyle;
    readonly wheelThumbStyle: typeof wheelThumbStyle;
    readonly markerWheelStyle: () => string;
    readonly markerStyle: typeof markerStyle;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorWheel, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColorWheel, "cp-wheel", never, { "label": { "alias": "label"; "required": false; }; "className": { "alias": "className"; "required": false; }; "classes": { "alias": "classes"; "required": false; }; "thumbText": { "alias": "thumbText"; "required": false; }; "markers": { "alias": "markers"; "required": false; }; "activeId": { "alias": "activeId"; "required": false; }; }, { "markerSelect": "markerSelect"; "markerChange": "markerChange"; }, never, never, true, never>;
}
export declare class ColorSlider {
    channel: SliderChannel;
    classes: ColorPartClasses;
    className: string;
    label: string;
    readonly labels: {
        h: string;
        s: string;
        v: string;
        alpha: string;
    };
    readonly sliderValue: (state: import("@sebytza23/color-picker-angular").ColorSnapshot, channel: SliderChannel) => number;
    readonly alphaTrackStyle: (hex: string) => string;
    readonly store: ColorStore;
    readonly state: import("@angular/core").Signal<import("@sebytza23/color-picker-angular").ColorSnapshot>;
    change(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorSlider, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColorSlider, "cp-slider", never, { "channel": { "alias": "channel"; "required": false; }; "classes": { "alias": "classes"; "required": false; }; "className": { "alias": "className"; "required": false; }; "label": { "alias": "label"; "required": false; }; }, {}, never, never, true, never>;
}
export declare class ColorTextInput {
    classes: ColorPartClasses;
    className: string;
    label: string;
    format?: ColorFormat;
    readonly state: import("@angular/core").Signal<import("@sebytza23/color-picker-angular").ColorSnapshot>;
    selectedFormat(): "hex" | "rgb" | "hsl" | "hsv" | "oklch" | "oklab";
    focused: boolean;
    readonly store: ColorStore;
    readonly draft: import("@angular/core").WritableSignal<string>;
    readonly invalid: import("@angular/core").WritableSignal<boolean>;
    ngOnChanges(): void;
    constructor();
    change(event: Event): void;
    reset(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorTextInput, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColorTextInput, "cp-text-input", never, { "classes": { "alias": "classes"; "required": false; }; "className": { "alias": "className"; "required": false; }; "label": { "alias": "label"; "required": false; }; "format": { "alias": "format"; "required": false; }; }, {}, never, never, true, never>;
}
export declare class ColorSwatch {
    value: string;
    label: string;
    readonly store: ColorStore;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorSwatch, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColorSwatch, "cp-swatch", never, { "value": { "alias": "value"; "required": false; }; "label": { "alias": "label"; "required": false; }; }, {}, never, never, true, never>;
}
export declare class ColorPreview {
    readonly state: import("@angular/core").Signal<import("@sebytza23/color-picker-angular").ColorSnapshot>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorPreview, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColorPreview, "cp-preview", never, {}, {}, never, never, true, never>;
}
export declare class ColorMode {
    readonly store: ColorStore;
    readonly state: import("@angular/core").Signal<import("@sebytza23/color-picker-angular").ColorSnapshot>;
    next(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorMode, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColorMode, "cp-mode", never, {}, {}, never, never, true, never>;
}
export declare class ColorFormatSelect {
    select: ElementRef<HTMLSelectElement>;
    constructor();
    label: string;
    readonly store: ColorStore;
    readonly state: import("@angular/core").Signal<import("@sebytza23/color-picker-angular").ColorSnapshot>;
    readonly formats: readonly ["hex", "rgb", "hsl", "hsv", "oklch", "oklab"];
    change(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorFormatSelect, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColorFormatSelect, "cp-format-select", never, { "label": { "alias": "label"; "required": false; }; }, {}, never, never, true, never>;
}
export declare class ColorChannelInput implements OnChanges {
    classes: ColorPartClasses;
    className: string;
    format: ChannelFormat;
    index: ChannelIndex;
    readonly store: ColorStore;
    readonly draft: import("@angular/core").WritableSignal<string>;
    readonly invalid: import("@angular/core").WritableSignal<boolean>;
    focused: boolean;
    constructor();
    spec(): import("@sebytza23/color-picker-angular").ChannelSpec;
    ngOnChanges(): void;
    change(event: Event): void;
    reset(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorChannelInput, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColorChannelInput, "cp-channel-input", never, { "classes": { "alias": "classes"; "required": false; }; "className": { "alias": "className"; "required": false; }; "format": { "alias": "format"; "required": false; }; "index": { "alias": "index"; "required": false; }; }, {}, never, never, true, never>;
}
export declare class ColorInput {
    classes: ColorPartClasses;
    className: string;
    format?: ColorFormat;
    label: string;
    readonly state: import("@angular/core").Signal<import("@sebytza23/color-picker-angular").ColorSnapshot>;
    readonly indices: ChannelIndex[];
    selectedFormat(): "hex" | "rgb" | "hsl" | "hsv" | "oklch" | "oklab";
    channelFormat(): ChannelFormat;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorInput, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColorInput, "cp-input", never, { "classes": { "alias": "classes"; "required": false; }; "className": { "alias": "className"; "required": false; }; "format": { "alias": "format"; "required": false; }; "label": { "alias": "label"; "required": false; }; }, {}, never, never, true, never>;
}
export declare class ColorViewSelect {
    select: ElementRef<HTMLSelectElement>;
    constructor();
    label: string;
    readonly store: ColorStore;
    readonly state: import("@angular/core").Signal<import("@sebytza23/color-picker-angular").ColorSnapshot>;
    readonly views: readonly ["area", "wheel"];
    change(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorViewSelect, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColorViewSelect, "cp-view-select", never, { "label": { "alias": "label"; "required": false; }; }, {}, never, never, true, never>;
}
export declare class ColorSurface {
    readonly state: import("@angular/core").Signal<import("@sebytza23/color-picker-angular").ColorSnapshot>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorSurface, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColorSurface, "cp-surface", never, {}, {}, never, never, true, never>;
}
export declare class ColorAlphaInput {
    label: string;
    className: string;
    classes: ColorPartClasses;
    input: ElementRef<HTMLInputElement>;
    readonly store: ColorStore;
    readonly state: import("@angular/core").Signal<import("@sebytza23/color-picker-angular").ColorSnapshot>;
    get initial(): number;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorAlphaInput, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColorAlphaInput, "cp-alpha-input", never, { "label": { "alias": "label"; "required": false; }; "className": { "alias": "className"; "required": false; }; "classes": { "alias": "classes"; "required": false; }; }, {}, never, never, true, never>;
}
