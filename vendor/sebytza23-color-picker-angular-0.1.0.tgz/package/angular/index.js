import { Component, Injectable, Input, Output, EventEmitter, inject, signal, DestroyRef, afterNextRender, afterRenderEffect, ViewChild, } from '@angular/core';
import { colorViews, bindMarkerWheel, markerWheelStyle, markerStyle, bindAlphaInput, sliderLabels, sliderValue, setSliderValue, alphaTrackStyle, channelSpecs, channelValue, setColorChannel, colorFormats, subscribeColor, parseColor, formatColor, areaStyle, wheelStyle, wheelThumbStyle, thumbStyle, bindColorArea, createColorStore, } from '@sebytza23/color-picker';
import * as i0 from "@angular/core";
export * from '@sebytza23/color-picker';
export class ColorContext {
    constructor() {
        this.current = createColorStore();
        this.listeners = new Set();
        this.forward = () => this.listeners.forEach((fn) => fn());
        this.unsubscribe = this.current.subscribe(this.forward);
        this.store = {
            getColor: () => this.current.getColor(),
            getValue: (format) => this.current.getValue(format),
            getSnapshot: () => this.current.getSnapshot(),
            getServerSnapshot: () => this.current.getServerSnapshot(),
            subscribe: (fn) => {
                this.listeners.add(fn);
                return () => {
                    this.listeners.delete(fn);
                };
            },
            setView: (view) => this.current.setView(view),
            setFormat: (format) => this.current.setFormat(format),
            setAlpha: (alpha) => this.current.setAlpha(alpha),
            setHex: (hex) => this.current.setHex(hex),
            setHSV: (hsv) => this.current.setHSV(hsv),
        };
        inject(DestroyRef).onDestroy(() => this.unsubscribe());
    }
    configure(store) {
        this.unsubscribe();
        this.current = store;
        this.unsubscribe = store.subscribe(this.forward);
        this.forward();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorContext, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorContext }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorContext, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });
export function useColorStore() {
    return inject(ColorContext).store;
}
export function useColor() {
    const store = useColorStore(), state = signal(store.getSnapshot());
    inject(DestroyRef).onDestroy(store.subscribe(() => state.set(store.getSnapshot())));
    return state.asReadonly();
}
export class ColorProvider {
    constructor() {
        this.view = 'area';
        this.colorChange = new EventEmitter();
        this.context = inject(ColorContext);
        this.destroyRef = inject(DestroyRef);
    }
    ngOnInit() {
        this.context.configure(this.store ?? createColorStore(this.value, 'hex', this.view));
        this.destroyRef.onDestroy(subscribeColor(this.context.store, (hex) => this.colorChange.emit(hex)));
    }
    ngOnChanges() {
        if (this.value !== undefined)
            this.context.store.setHex(this.value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorProvider, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: ColorProvider, isStandalone: true, selector: "cp-provider", inputs: { value: "value", view: "view", store: "store" }, outputs: { colorChange: "colorChange" }, providers: [ColorContext], usesOnChanges: true, ngImport: i0, template: '<ng-content />', isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorProvider, decorators: [{
            type: Component,
            args: [{
                    selector: 'cp-provider',
                    standalone: true,
                    providers: [ColorContext],
                    template: '<ng-content />',
                }]
        }], propDecorators: { value: [{
                type: Input
            }], view: [{
                type: Input
            }], store: [{
                type: Input
            }], colorChange: [{
                type: Output
            }] } });
export class ColorArea {
    constructor() {
        this.classes = {};
        this.className = '';
        this.thumbText = '';
        this.label = 'Saturation and brightness';
        this.store = useColorStore();
        this.state = useColor();
        this.areaStyle = areaStyle;
        this.thumbStyle = thumbStyle;
        let cleanup;
        afterNextRender(() => {
            cleanup = bindColorArea(this.area.nativeElement, this.store);
        });
        inject(DestroyRef).onDestroy(() => cleanup?.());
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorArea, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: ColorArea, isStandalone: true, selector: "cp-area", inputs: { classes: "classes", className: "className", thumbText: "thumbText", label: "label" }, viewQueries: [{ propertyName: "area", first: true, predicate: ["area"], descendants: true }], ngImport: i0, template: `<div
    #area
    data-cp-part="surface"
    [class]="'cp-area ' + className + ' ' + (classes.root ?? '')"
    role="group"
    tabindex="0"
    [attr.aria-label]="
      label +
      '. Arrow keys adjust; Shift for larger steps. ' +
      state().s.toFixed(0) +
      '% saturation, ' +
      state().v.toFixed(0) +
      '% brightness.'
    "
    [style]="areaStyle(state())"
  >
    <span
      data-cp-part="thumb"
      [class]="classes.thumb ?? ''"
      aria-hidden="true"
      [style]="thumbStyle(state())"
      ><span data-cp-part="thumb-text" [class]="classes.text ?? ''"
        >{{ thumbText }}<ng-content select="[cpThumb]" /></span
    ></span>
  </div>`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorArea, decorators: [{
            type: Component,
            args: [{
                    selector: 'cp-area',
                    standalone: true,
                    template: `<div
    #area
    data-cp-part="surface"
    [class]="'cp-area ' + className + ' ' + (classes.root ?? '')"
    role="group"
    tabindex="0"
    [attr.aria-label]="
      label +
      '. Arrow keys adjust; Shift for larger steps. ' +
      state().s.toFixed(0) +
      '% saturation, ' +
      state().v.toFixed(0) +
      '% brightness.'
    "
    [style]="areaStyle(state())"
  >
    <span
      data-cp-part="thumb"
      [class]="classes.thumb ?? ''"
      aria-hidden="true"
      [style]="thumbStyle(state())"
      ><span data-cp-part="thumb-text" [class]="classes.text ?? ''"
        >{{ thumbText }}<ng-content select="[cpThumb]" /></span
    ></span>
  </div>`,
                }]
        }], ctorParameters: () => [], propDecorators: { classes: [{
                type: Input
            }], className: [{
                type: Input
            }], thumbText: [{
                type: Input
            }], label: [{
                type: Input
            }], area: [{
                type: ViewChild,
                args: ['area']
            }] } });
export class ColorWheel {
    constructor() {
        this.label = 'Hue and saturation wheel';
        this.className = '';
        this.classes = {};
        this.thumbText = '';
        this.markerSelect = new EventEmitter();
        this.markerChange = new EventEmitter();
        this.store = useColorStore();
        this.state = useColor();
        this.wheelStyle = wheelStyle;
        this.wheelThumbStyle = wheelThumbStyle;
        this.markerWheelStyle = markerWheelStyle;
        this.markerStyle = markerStyle;
        let cleanup;
        afterNextRender(() => {
            cleanup = this.markers
                ? bindMarkerWheel(this.area.nativeElement, {
                    getMarkers: () => this.markers ?? [],
                    getActiveId: () => this.activeId ?? this.markers?.[0]?.id ?? '',
                    select: (id) => this.markerSelect.emit(id),
                    setHSV: (id, hsv) => this.markerChange.emit({ id, hsv }),
                })
                : bindColorArea(this.area.nativeElement, this.store, 'wheel');
        });
        inject(DestroyRef).onDestroy(() => cleanup?.());
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorWheel, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: ColorWheel, isStandalone: true, selector: "cp-wheel", inputs: { label: "label", className: "className", classes: "classes", thumbText: "thumbText", markers: "markers", activeId: "activeId" }, outputs: { markerSelect: "markerSelect", markerChange: "markerChange" }, viewQueries: [{ propertyName: "area", first: true, predicate: ["area"], descendants: true }], ngImport: i0, template: `<div
    #area
    data-cp-part="surface"
    [class]="'cp-wheel ' + className + ' ' + (classes.root ?? '')"
    role="group"
    tabindex="0"
    [attr.aria-label]="label"
    [style]="markers ? markerWheelStyle() : wheelStyle(state())"
  >
    @if (markers) {
      @for (marker of markers; track marker.id) {
        <button
          type="button"
          data-cp-part="marker"
          [attr.data-marker-id]="marker.id"
          [attr.data-small]="
            markers.length === 1 || !marker.label ? 'true' : null
          "
          [class]="'cp-wheel-marker ' + (classes.marker ?? '')"
          [attr.aria-label]="
            marker.ariaLabel ?? 'Select ' + marker.id + ' marker'
          "
          [attr.aria-pressed]="activeId === marker.id"
          [style]="markerStyle(marker, activeId === marker.id)"
        >
          <span data-cp-part="marker-text" [class]="classes.text ?? ''">{{
            marker.label ?? ''
          }}</span>
        </button>
      }
    } @else {
      <span
        data-cp-part="thumb"
        aria-hidden="true"
        [class]="classes.thumb ?? ''"
        [style]="wheelThumbStyle(state())"
        ><span data-cp-part="thumb-text" [class]="classes.text ?? ''">{{
          thumbText
        }}</span></span
      >
    }
  </div>`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorWheel, decorators: [{
            type: Component,
            args: [{
                    selector: 'cp-wheel',
                    standalone: true,
                    template: `<div
    #area
    data-cp-part="surface"
    [class]="'cp-wheel ' + className + ' ' + (classes.root ?? '')"
    role="group"
    tabindex="0"
    [attr.aria-label]="label"
    [style]="markers ? markerWheelStyle() : wheelStyle(state())"
  >
    @if (markers) {
      @for (marker of markers; track marker.id) {
        <button
          type="button"
          data-cp-part="marker"
          [attr.data-marker-id]="marker.id"
          [attr.data-small]="
            markers.length === 1 || !marker.label ? 'true' : null
          "
          [class]="'cp-wheel-marker ' + (classes.marker ?? '')"
          [attr.aria-label]="
            marker.ariaLabel ?? 'Select ' + marker.id + ' marker'
          "
          [attr.aria-pressed]="activeId === marker.id"
          [style]="markerStyle(marker, activeId === marker.id)"
        >
          <span data-cp-part="marker-text" [class]="classes.text ?? ''">{{
            marker.label ?? ''
          }}</span>
        </button>
      }
    } @else {
      <span
        data-cp-part="thumb"
        aria-hidden="true"
        [class]="classes.thumb ?? ''"
        [style]="wheelThumbStyle(state())"
        ><span data-cp-part="thumb-text" [class]="classes.text ?? ''">{{
          thumbText
        }}</span></span
      >
    }
  </div>`,
                }]
        }], ctorParameters: () => [], propDecorators: { label: [{
                type: Input
            }], className: [{
                type: Input
            }], classes: [{
                type: Input
            }], thumbText: [{
                type: Input
            }], markers: [{
                type: Input
            }], activeId: [{
                type: Input
            }], markerSelect: [{
                type: Output
            }], markerChange: [{
                type: Output
            }], area: [{
                type: ViewChild,
                args: ['area']
            }] } });
export class ColorSlider {
    constructor() {
        this.channel = 'h';
        this.classes = {};
        this.className = '';
        this.label = '';
        this.labels = sliderLabels;
        this.sliderValue = sliderValue;
        this.alphaTrackStyle = alphaTrackStyle;
        this.store = useColorStore();
        this.state = useColor();
    }
    change(event) {
        setSliderValue(this.store, this.channel, Number(event.target.value));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorSlider, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: ColorSlider, isStandalone: true, selector: "cp-slider", inputs: { channel: "channel", classes: "classes", className: "className", label: "label" }, ngImport: i0, template: `<label
    data-cp-part="slider"
    [class]="
      'cp-slider ' +
      className +
      ' ' +
      (classes.root ?? '') +
      ' ' +
      (classes.label ?? '')
    "
    [style]="alphaTrackStyle(state().hex)"
    [attr.data-channel]="channel"
    >{{ label || labels[channel]
    }}<input
      data-cp-part="track"
      [class]="(classes.track ?? '') + ' ' + (classes.input ?? '')"
      type="range"
      min="0"
      [max]="channel === 'h' ? 359 : 100"
      step="1"
      [value]="sliderValue(state(), channel)"
      (input)="change($event)"
  /></label>`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorSlider, decorators: [{
            type: Component,
            args: [{
                    selector: 'cp-slider',
                    standalone: true,
                    template: `<label
    data-cp-part="slider"
    [class]="
      'cp-slider ' +
      className +
      ' ' +
      (classes.root ?? '') +
      ' ' +
      (classes.label ?? '')
    "
    [style]="alphaTrackStyle(state().hex)"
    [attr.data-channel]="channel"
    >{{ label || labels[channel]
    }}<input
      data-cp-part="track"
      [class]="(classes.track ?? '') + ' ' + (classes.input ?? '')"
      type="range"
      min="0"
      [max]="channel === 'h' ? 359 : 100"
      step="1"
      [value]="sliderValue(state(), channel)"
      (input)="change($event)"
  /></label>`,
                }]
        }], propDecorators: { channel: [{
                type: Input
            }], classes: [{
                type: Input
            }], className: [{
                type: Input
            }], label: [{
                type: Input
            }] } });
export class ColorTextInput {
    selectedFormat() {
        return this.format ?? this.state().format;
    }
    ngOnChanges() {
        this.reset();
    }
    constructor() {
        this.classes = {};
        this.className = '';
        this.label = '';
        this.state = useColor();
        this.focused = false;
        this.store = useColorStore();
        this.draft = signal(this.store.getSnapshot().hex);
        this.invalid = signal(false);
        inject(DestroyRef).onDestroy(this.store.subscribe(() => {
            if (!this.focused)
                this.reset();
        }));
    }
    change(event) {
        const value = event.target.value;
        this.draft.set(value);
        try {
            this.store.setHex(parseColor(value, this.selectedFormat()));
            this.invalid.set(false);
        }
        catch {
            this.invalid.set(true);
        }
    }
    reset() {
        this.draft.set(formatColor(this.store.getSnapshot().hex, this.selectedFormat(), this.store.getSnapshot().alpha));
        this.invalid.set(false);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorTextInput, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: ColorTextInput, isStandalone: true, selector: "cp-text-input", inputs: { classes: "classes", className: "className", label: "label", format: "format" }, usesOnChanges: true, ngImport: i0, template: `<label
    [class]="
      'cp-input ' +
      className +
      ' ' +
      (classes.root ?? '') +
      ' ' +
      (classes.label ?? '')
    "
    >{{ label || selectedFormat().toUpperCase()
    }}<input
      data-cp-part="input"
      [class]="classes.input ?? ''"
      [value]="draft()"
      spellcheck="false"
      [attr.maxlength]="selectedFormat() === 'hex' ? 9 : 64"
      [attr.aria-invalid]="invalid()"
      (input)="change($event)"
      (focus)="focused = true"
      (blur)="focused = false; reset()"
      (keydown.enter)="reset()"
  /></label>`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorTextInput, decorators: [{
            type: Component,
            args: [{
                    selector: 'cp-text-input',
                    standalone: true,
                    template: `<label
    [class]="
      'cp-input ' +
      className +
      ' ' +
      (classes.root ?? '') +
      ' ' +
      (classes.label ?? '')
    "
    >{{ label || selectedFormat().toUpperCase()
    }}<input
      data-cp-part="input"
      [class]="classes.input ?? ''"
      [value]="draft()"
      spellcheck="false"
      [attr.maxlength]="selectedFormat() === 'hex' ? 9 : 64"
      [attr.aria-invalid]="invalid()"
      (input)="change($event)"
      (focus)="focused = true"
      (blur)="focused = false; reset()"
      (keydown.enter)="reset()"
  /></label>`,
                }]
        }], ctorParameters: () => [], propDecorators: { classes: [{
                type: Input
            }], className: [{
                type: Input
            }], label: [{
                type: Input
            }], format: [{
                type: Input
            }] } });
export class ColorSwatch {
    constructor() {
        this.value = '#6366F1';
        this.label = '';
        this.store = useColorStore();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorSwatch, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: ColorSwatch, isStandalone: true, selector: "cp-swatch", inputs: { value: "value", label: "label" }, ngImport: i0, template: `<button
    type="button"
    class="cp-swatch"
    [attr.aria-label]="label || value"
    [style.background]="value"
    (click)="store.setHex(value)"
  ></button>`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorSwatch, decorators: [{
            type: Component,
            args: [{
                    selector: 'cp-swatch',
                    standalone: true,
                    template: `<button
    type="button"
    class="cp-swatch"
    [attr.aria-label]="label || value"
    [style.background]="value"
    (click)="store.setHex(value)"
  ></button>`,
                }]
        }], propDecorators: { value: [{
                type: Input
            }], label: [{
                type: Input
            }] } });
export class ColorPreview {
    constructor() {
        this.state = useColor();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorPreview, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: ColorPreview, isStandalone: true, selector: "cp-preview", ngImport: i0, template: `<output
    class="cp-preview"
    [style.background]="state().value"
    [attr.aria-label]="'Selected color ' + state().value"
    >{{ state().value }}</output
  >`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorPreview, decorators: [{
            type: Component,
            args: [{
                    selector: 'cp-preview',
                    standalone: true,
                    template: `<output
    class="cp-preview"
    [style.background]="state().value"
    [attr.aria-label]="'Selected color ' + state().value"
    >{{ state().value }}</output
  >`,
                }]
        }] });
export class ColorMode {
    constructor() {
        this.store = useColorStore();
        this.state = useColor();
    }
    next() {
        this.store.setFormat(colorFormats[(colorFormats.indexOf(this.state().format) + 1) % colorFormats.length]);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorMode, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: ColorMode, isStandalone: true, selector: "cp-mode", ngImport: i0, template: `<button
    type="button"
    class="cp-mode"
    [attr.aria-label]="
      'Next color format (' + state().format.toUpperCase() + ')'
    "
    (click)="next()"
  >
    {{ state().format.toUpperCase() }} ↔
  </button>`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorMode, decorators: [{
            type: Component,
            args: [{
                    selector: 'cp-mode',
                    standalone: true,
                    template: `<button
    type="button"
    class="cp-mode"
    [attr.aria-label]="
      'Next color format (' + state().format.toUpperCase() + ')'
    "
    (click)="next()"
  >
    {{ state().format.toUpperCase() }} ↔
  </button>`,
                }]
        }] });
export class ColorFormatSelect {
    constructor() {
        this.label = 'Color format';
        this.store = useColorStore();
        this.state = useColor();
        this.formats = colorFormats;
        afterRenderEffect(() => {
            this.select.nativeElement.value = this.state().format;
        });
    }
    change(event) {
        this.store.setFormat(event.target.value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorFormatSelect, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: ColorFormatSelect, isStandalone: true, selector: "cp-format-select", inputs: { label: "label" }, viewQueries: [{ propertyName: "select", first: true, predicate: ["select"], descendants: true }], ngImport: i0, template: `<label class="cp-format"
    >{{ label
    }}<select #select (change)="change($event)">
      @for (format of formats; track format) {
        <option
          [value]="format"
          [attr.selected]="state().format === format ? '' : null"
        >
          {{ format.toUpperCase() }}
        </option>
      }
    </select></label
  >`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorFormatSelect, decorators: [{
            type: Component,
            args: [{
                    selector: 'cp-format-select',
                    standalone: true,
                    template: `<label class="cp-format"
    >{{ label
    }}<select #select (change)="change($event)">
      @for (format of formats; track format) {
        <option
          [value]="format"
          [attr.selected]="state().format === format ? '' : null"
        >
          {{ format.toUpperCase() }}
        </option>
      }
    </select></label
  >`,
                }]
        }], ctorParameters: () => [], propDecorators: { select: [{
                type: ViewChild,
                args: ['select']
            }], label: [{
                type: Input
            }] } });
export class ColorChannelInput {
    constructor() {
        this.classes = {};
        this.className = '';
        this.format = 'rgb';
        this.index = 0;
        this.store = useColorStore();
        this.draft = signal(channelValue(this.store.getSnapshot(), 'rgb', 0));
        this.invalid = signal(false);
        this.focused = false;
        inject(DestroyRef).onDestroy(this.store.subscribe(() => {
            if (!this.focused)
                this.reset();
        }));
    }
    spec() {
        return channelSpecs[this.format][this.index];
    }
    ngOnChanges() {
        this.reset();
    }
    change(event) {
        const raw = event.target.value;
        this.draft.set(raw);
        try {
            if (!raw.trim())
                throw new Error('Incomplete');
            setColorChannel(this.store, this.format, this.index, Number(raw));
            this.invalid.set(false);
        }
        catch {
            this.invalid.set(true);
        }
    }
    reset() {
        this.draft.set(channelValue(this.store.getSnapshot(), this.format, this.index));
        this.invalid.set(false);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorChannelInput, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: ColorChannelInput, isStandalone: true, selector: "cp-channel-input", inputs: { classes: "classes", className: "className", format: "format", index: "index" }, usesOnChanges: true, ngImport: i0, template: `<label
    [class]="
      'cp-channel ' +
      className +
      ' ' +
      (classes.root ?? '') +
      ' ' +
      (classes.label ?? '')
    "
    ><span>{{ spec().label }}</span
    ><span class="cp-channel-field"
      ><input
        data-cp-part="input"
        [class]="classes.input ?? ''"
        type="number"
        [attr.aria-label]="format.toUpperCase() + ' ' + spec().label"
        [min]="spec().min"
        [max]="spec().max"
        [step]="spec().step"
        [value]="draft()"
        [attr.aria-invalid]="invalid()"
        (focus)="focused = true"
        (input)="change($event)"
        (blur)="focused = false; reset()"
        (keydown.enter)="reset()"
      /><span aria-hidden="true">{{ spec().unit }}</span></span
    ></label
  >`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorChannelInput, decorators: [{
            type: Component,
            args: [{
                    selector: 'cp-channel-input',
                    standalone: true,
                    template: `<label
    [class]="
      'cp-channel ' +
      className +
      ' ' +
      (classes.root ?? '') +
      ' ' +
      (classes.label ?? '')
    "
    ><span>{{ spec().label }}</span
    ><span class="cp-channel-field"
      ><input
        data-cp-part="input"
        [class]="classes.input ?? ''"
        type="number"
        [attr.aria-label]="format.toUpperCase() + ' ' + spec().label"
        [min]="spec().min"
        [max]="spec().max"
        [step]="spec().step"
        [value]="draft()"
        [attr.aria-invalid]="invalid()"
        (focus)="focused = true"
        (input)="change($event)"
        (blur)="focused = false; reset()"
        (keydown.enter)="reset()"
      /><span aria-hidden="true">{{ spec().unit }}</span></span
    ></label
  >`,
                }]
        }], ctorParameters: () => [], propDecorators: { classes: [{
                type: Input
            }], className: [{
                type: Input
            }], format: [{
                type: Input
            }], index: [{
                type: Input
            }] } });
export class ColorInput {
    constructor() {
        this.classes = {};
        this.className = '';
        this.label = '';
        this.state = useColor();
        this.indices = [0, 1, 2];
    }
    selectedFormat() {
        return this.format ?? this.state().format;
    }
    channelFormat() {
        return this.selectedFormat();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorInput, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: ColorInput, isStandalone: true, selector: "cp-input", inputs: { classes: "classes", className: "className", format: "format", label: "label" }, ngImport: i0, template: `@if (selectedFormat() === 'hex') {
      <cp-text-input
        format="hex"
        [classes]="classes"
        [className]="className"
        [label]="label || 'HEX'"
      />
    } @else {
      <div
        class="cp-channels"
        role="group"
        [attr.aria-label]="label || selectedFormat().toUpperCase()"
      >
        @for (index of indices; track index) {
          <cp-channel-input
            [classes]="classes"
            [className]="className"
            [format]="channelFormat()"
            [index]="index"
          />
        }
      </div>
    }`, isInline: true, dependencies: [{ kind: "component", type: ColorTextInput, selector: "cp-text-input", inputs: ["classes", "className", "label", "format"] }, { kind: "component", type: ColorChannelInput, selector: "cp-channel-input", inputs: ["classes", "className", "format", "index"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorInput, decorators: [{
            type: Component,
            args: [{
                    selector: 'cp-input',
                    standalone: true,
                    imports: [ColorTextInput, ColorChannelInput],
                    template: `@if (selectedFormat() === 'hex') {
      <cp-text-input
        format="hex"
        [classes]="classes"
        [className]="className"
        [label]="label || 'HEX'"
      />
    } @else {
      <div
        class="cp-channels"
        role="group"
        [attr.aria-label]="label || selectedFormat().toUpperCase()"
      >
        @for (index of indices; track index) {
          <cp-channel-input
            [classes]="classes"
            [className]="className"
            [format]="channelFormat()"
            [index]="index"
          />
        }
      </div>
    }`,
                }]
        }], propDecorators: { classes: [{
                type: Input
            }], className: [{
                type: Input
            }], format: [{
                type: Input
            }], label: [{
                type: Input
            }] } });
export class ColorViewSelect {
    constructor() {
        this.label = 'Picker view';
        this.store = useColorStore();
        this.state = useColor();
        this.views = colorViews;
        afterRenderEffect(() => {
            this.select.nativeElement.value = this.state().view;
        });
    }
    change(event) {
        this.store.setView(event.target.value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorViewSelect, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: ColorViewSelect, isStandalone: true, selector: "cp-view-select", inputs: { label: "label" }, viewQueries: [{ propertyName: "select", first: true, predicate: ["select"], descendants: true }], ngImport: i0, template: `<label class="cp-format"
    >{{ label
    }}<select #select (change)="change($event)">
      @for (view of views; track view) {
        <option
          [value]="view"
          [attr.selected]="state().view === view ? '' : null"
        >
          {{ view === 'area' ? 'Rectangle' : 'Wheel' }}
        </option>
      }
    </select></label
  >`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorViewSelect, decorators: [{
            type: Component,
            args: [{
                    selector: 'cp-view-select',
                    standalone: true,
                    template: `<label class="cp-format"
    >{{ label
    }}<select #select (change)="change($event)">
      @for (view of views; track view) {
        <option
          [value]="view"
          [attr.selected]="state().view === view ? '' : null"
        >
          {{ view === 'area' ? 'Rectangle' : 'Wheel' }}
        </option>
      }
    </select></label
  >`,
                }]
        }], ctorParameters: () => [], propDecorators: { select: [{
                type: ViewChild,
                args: ['select']
            }], label: [{
                type: Input
            }] } });
export class ColorSurface {
    constructor() {
        this.state = useColor();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorSurface, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: ColorSurface, isStandalone: true, selector: "cp-surface", ngImport: i0, template: `@if (state().view === 'wheel') {
      <cp-wheel />
    } @else {
      <cp-area />
    }
    <cp-slider [channel]="state().view === 'wheel' ? 'v' : 'h'" />`, isInline: true, dependencies: [{ kind: "component", type: ColorArea, selector: "cp-area", inputs: ["classes", "className", "thumbText", "label"] }, { kind: "component", type: ColorWheel, selector: "cp-wheel", inputs: ["label", "className", "classes", "thumbText", "markers", "activeId"], outputs: ["markerSelect", "markerChange"] }, { kind: "component", type: ColorSlider, selector: "cp-slider", inputs: ["channel", "classes", "className", "label"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorSurface, decorators: [{
            type: Component,
            args: [{
                    selector: 'cp-surface',
                    standalone: true,
                    imports: [ColorArea, ColorWheel, ColorSlider],
                    template: `@if (state().view === 'wheel') {
      <cp-wheel />
    } @else {
      <cp-area />
    }
    <cp-slider [channel]="state().view === 'wheel' ? 'v' : 'h'" />`,
                }]
        }] });
export class ColorAlphaInput {
    get initial() {
        return Number((this.state().alpha * 100).toFixed(4));
    }
    constructor() {
        this.label = 'Alpha';
        this.className = '';
        this.classes = {};
        this.store = useColorStore();
        this.state = useColor();
        let cleanup;
        afterNextRender(() => (cleanup = bindAlphaInput(this.input.nativeElement, this.store)));
        inject(DestroyRef).onDestroy(() => cleanup?.());
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorAlphaInput, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: ColorAlphaInput, isStandalone: true, selector: "cp-alpha-input", inputs: { label: "label", className: "className", classes: "classes" }, viewQueries: [{ propertyName: "input", first: true, predicate: ["input"], descendants: true }], ngImport: i0, template: `<label
    data-cp-part="alpha-input"
    [class]="
      'cp-alpha-input cp-channel ' +
      className +
      ' ' +
      (classes.root ?? '') +
      ' ' +
      (classes.label ?? '')
    "
    >{{ label
    }}<span class="cp-channel-field"
      ><input
        #input
        data-cp-part="input"
        [class]="classes.input ?? ''"
        type="number"
        min="0"
        max="100"
        step="0.1"
        [attr.value]="initial"
        [attr.aria-label]="label"
      /><span>%</span></span
    ></label
  >`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ColorAlphaInput, decorators: [{
            type: Component,
            args: [{
                    selector: 'cp-alpha-input',
                    standalone: true,
                    template: `<label
    data-cp-part="alpha-input"
    [class]="
      'cp-alpha-input cp-channel ' +
      className +
      ' ' +
      (classes.root ?? '') +
      ' ' +
      (classes.label ?? '')
    "
    >{{ label
    }}<span class="cp-channel-field"
      ><input
        #input
        data-cp-part="input"
        [class]="classes.input ?? ''"
        type="number"
        min="0"
        max="100"
        step="0.1"
        [attr.value]="initial"
        [attr.aria-label]="label"
      /><span>%</span></span
    ></label
  >`,
                }]
        }], ctorParameters: () => [], propDecorators: { label: [{
                type: Input
            }], className: [{
                type: Input
            }], classes: [{
                type: Input
            }], input: [{
                type: ViewChild,
                args: ['input']
            }] } });
