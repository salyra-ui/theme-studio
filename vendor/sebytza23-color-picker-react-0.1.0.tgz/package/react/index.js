"use client";
"use client";

// packages/color-picker/react/index.tsx
export * from '@sebytza23/color-picker';
import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  useSyncExternalStore
} from "react";
import {
  colorViews,
  bindMarkerWheel,
  markerWheelStyle,
  markerStyle,
  bindAlphaInput,
  sliderLabels,
  sliderValue,
  setSliderValue,
  channelSpecs,
  wheelStyle,
  wheelThumbStyle,
  channelValue,
  setColorChannel,
  colorFormats,
  subscribeColor,
  parseColor,
  formatColor,
  bindColorArea,
  createColorStore
} from '@sebytza23/color-picker';
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
var Context = createContext(null);
function useColorStore() {
  const store = useContext(Context);
  if (!store) throw new Error("Color components require ColorProvider");
  return store;
}
function useColor() {
  const store = useColorStore();
  return useSyncExternalStore(
    store.subscribe,
    store.getSnapshot,
    store.getServerSnapshot
  );
}
function ColorProvider({
  value,
  view = "area",
  onChange,
  children,
  disabled,
  store: provided
}) {
  const [store] = useState(() => {
    const initial = provided ?? createColorStore(value, "hex", view, disabled);
    if (disabled !== void 0) initial.setDisabled(disabled);
    return initial;
  });
  const state = useSyncExternalStore(
    store.subscribe,
    store.getSnapshot,
    store.getServerSnapshot
  );
  useEffect(() => {
    if (disabled !== void 0) store.setDisabled(disabled);
  }, [store, disabled]);
  const callback = useRef(onChange);
  callback.current = onChange;
  useEffect(() => {
    if (value !== void 0) store.setHex(value);
  }, [store, value]);
  useEffect(
    () => subscribeColor(store, (hex) => callback.current?.(hex)),
    [store]
  );
  return /* @__PURE__ */ jsx(Context.Provider, { value: store, children: /* @__PURE__ */ jsx(
    "fieldset",
    {
      className: "cp-provider-controls",
      disabled: state.disabled,
      ...state.disabled ? { inert: "" } : {},
      "aria-disabled": state.disabled,
      "data-disabled": state.disabled,
      children
    }
  ) });
}
function ColorArea({
  className = "",
  style,
  classes = {},
  thumbText,
  renderThumb,
  label = "Saturation and brightness"
}) {
  const store = useColorStore(), state = useColor(), ref = useRef(null);
  useEffect(() => bindColorArea(ref.current, store), [store]);
  return /* @__PURE__ */ jsx(
    "div",
    {
      ref,
      className: `cp-area ${className} ${classes.root ?? ""}`,
      "data-cp-part": "surface",
      role: "group",
      tabIndex: 0,
      "aria-label": `${label}. Arrow keys adjust; Shift for larger steps. ${Math.round(state.s)}% saturation, ${Math.round(state.v)}% brightness.`,
      style: {
        position: "relative",
        touchAction: "none",
        minWidth: 160,
        minHeight: 120,
        background: `linear-gradient(to top,#000,transparent),linear-gradient(to right,#fff,transparent),hsl(${state.h} 100% 50%)`,
        ...style
      },
      children: /* @__PURE__ */ jsx(
        "span",
        {
          "data-cp-part": "thumb",
          className: classes.thumb,
          "aria-hidden": true,
          style: {
            position: "absolute",
            left: `${state.s}%`,
            top: `${100 - state.v}%`,
            transform: "translate(-50%,-50%)",
            width: "var(--cp-thumb-size,12px)",
            height: "var(--cp-thumb-size,12px)",
            border: "var(--cp-thumb-border,2px solid white)",
            boxShadow: "var(--cp-thumb-shadow,0 0 0 1px #000)",
            borderRadius: "var(--cp-thumb-radius,50%)",
            pointerEvents: "none",
            display: "grid",
            placeItems: "center"
          },
          children: /* @__PURE__ */ jsx("span", { "data-cp-part": "thumb-text", className: classes.text, children: renderThumb ? renderThumb(state) : thumbText })
        }
      )
    }
  );
}
function ColorSlider({
  channel = "h",
  label,
  className = "",
  classes = {}
}) {
  const store = useColorStore(), state = useColor();
  return /* @__PURE__ */ jsxs(
    "label",
    {
      className: `cp-slider ${className} ${classes.root ?? ""} ${classes.label ?? ""}`,
      style: { "--cp-alpha-color": state.hex },
      "data-cp-part": "slider",
      "data-channel": channel,
      children: [
        label ?? sliderLabels[channel],
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "range",
            "data-cp-part": "track",
            className: `${classes.track ?? ""} ${classes.input ?? ""}`,
            min: 0,
            max: channel === "h" ? 359 : 100,
            step: 1,
            value: sliderValue(state, channel),
            onChange: (e) => setSliderValue(store, channel, Number(e.target.value))
          }
        )
      ]
    }
  );
}
function ColorTextInput({
  format: override,
  label,
  className = "",
  classes = {}
}) {
  const store = useColorStore(), state = useColor(), format = override ?? state.format, focused = useRef(false), [draft, setDraft] = useState(
    () => formatColor(state.hex, format, state.alpha)
  ), [invalid, setInvalid] = useState(false);
  useEffect(() => {
    if (!focused.current) {
      setDraft(formatColor(state.hex, format, state.alpha));
      setInvalid(false);
    }
  }, [state.hex, state.alpha, format]);
  const reset = () => {
    setDraft(
      formatColor(store.getSnapshot().hex, format, store.getSnapshot().alpha)
    );
    setInvalid(false);
  };
  return /* @__PURE__ */ jsxs(
    "label",
    {
      className: `cp-input ${className} ${classes.root ?? ""} ${classes.label ?? ""}`,
      children: [
        label ?? format.toUpperCase(),
        /* @__PURE__ */ jsx(
          "input",
          {
            "data-cp-part": "input",
            className: classes.input,
            value: draft,
            spellCheck: false,
            maxLength: format === "hex" ? 9 : 64,
            "aria-invalid": invalid,
            onFocus: () => {
              focused.current = true;
            },
            onChange: (e) => {
              const text = e.target.value;
              setDraft(text);
              try {
                store.setHex(parseColor(text, format));
                setInvalid(false);
              } catch {
                setInvalid(true);
              }
            },
            onBlur: () => {
              focused.current = false;
              reset();
            },
            onKeyDown: (e) => {
              if (e.key === "Enter") reset();
            }
          }
        )
      ]
    }
  );
}
function ColorSwatch({
  value,
  label = value,
  className = ""
}) {
  const store = useColorStore();
  return /* @__PURE__ */ jsx(
    "button",
    {
      type: "button",
      className: `cp-swatch ${className}`,
      "aria-label": label,
      style: { background: value },
      onClick: () => store.setHex(value)
    }
  );
}
function ColorPreview({ className = "" }) {
  const state = useColor();
  return /* @__PURE__ */ jsx(
    "output",
    {
      className: `cp-preview ${className}`,
      style: { background: state.value },
      "aria-label": `Selected color ${state.value}`,
      children: state.value
    }
  );
}
function ColorMode({
  className = "",
  children
}) {
  const store = useColorStore(), state = useColor();
  return /* @__PURE__ */ jsx(
    "button",
    {
      type: "button",
      className: `cp-mode ${className}`,
      "aria-label": `Next color format (${state.format.toUpperCase()})`,
      onClick: () => store.setFormat(
        colorFormats[(colorFormats.indexOf(state.format) + 1) % colorFormats.length]
      ),
      children: typeof children === "function" ? children(state.format) : children ?? `${state.format.toUpperCase()} \u2194`
    }
  );
}
function ColorFormatSelect({
  label = "Color format",
  className = ""
}) {
  const store = useColorStore(), state = useColor();
  return /* @__PURE__ */ jsxs("label", { className: `cp-format ${className}`, children: [
    label,
    /* @__PURE__ */ jsx(
      "select",
      {
        "data-cp-part": "select",
        value: state.format,
        onChange: (e) => store.setFormat(e.target.value),
        children: colorFormats.map((format) => /* @__PURE__ */ jsx("option", { value: format, children: format.toUpperCase() }, format))
      }
    )
  ] });
}
function ColorChannelInput({
  format,
  index,
  className = "",
  classes = {}
}) {
  const store = useColorStore(), state = useColor(), spec = channelSpecs[format][index], focused = useRef(false);
  const [draft, setDraft] = useState(() => channelValue(state, format, index)), [invalid, setInvalid] = useState(false);
  useEffect(() => {
    if (!focused.current) {
      setDraft(channelValue(state, format, index));
      setInvalid(false);
    }
  }, [state, format, index]);
  const reset = () => {
    setDraft(channelValue(store.getSnapshot(), format, index));
    setInvalid(false);
  };
  return /* @__PURE__ */ jsxs(
    "label",
    {
      className: `cp-channel ${className} ${classes.root ?? ""} ${classes.label ?? ""}`,
      children: [
        /* @__PURE__ */ jsx("span", { className: classes.text, children: spec.label }),
        /* @__PURE__ */ jsxs("span", { className: "cp-channel-field", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              "data-cp-part": "input",
              className: classes.input,
              type: "number",
              "aria-label": `${format.toUpperCase()} ${spec.label}`,
              min: spec.min,
              max: spec.max,
              step: spec.step,
              value: draft,
              "aria-invalid": invalid,
              onFocus: () => {
                focused.current = true;
              },
              onChange: (e) => {
                const raw = e.target.value;
                setDraft(raw);
                try {
                  if (!raw.trim()) throw new Error("Incomplete");
                  setColorChannel(store, format, index, Number(raw));
                  setInvalid(false);
                } catch {
                  setInvalid(true);
                }
              },
              onBlur: () => {
                focused.current = false;
                reset();
              },
              onKeyDown: (e) => {
                if (e.key === "Enter") reset();
              }
            }
          ),
          /* @__PURE__ */ jsx("span", { "aria-hidden": true, children: spec.unit })
        ] })
      ]
    }
  );
}
function ColorInput({
  format: override,
  label,
  className = "",
  classes = {}
}) {
  const state = useColor(), format = override ?? state.format;
  return format === "hex" ? /* @__PURE__ */ jsx(
    ColorTextInput,
    {
      format: "hex",
      label: label ?? "HEX",
      className,
      classes
    }
  ) : /* @__PURE__ */ jsx(
    "div",
    {
      className: `cp-channels ${className}`,
      role: "group",
      "aria-label": label ?? format.toUpperCase(),
      children: [0, 1, 2].map((index) => /* @__PURE__ */ jsx(
        ColorChannelInput,
        {
          classes,
          format,
          index
        },
        `${format}-${index}`
      ))
    }
  );
}
function ColorWheel({
  className = "",
  label = "Hue and saturation wheel",
  classes = {},
  thumbText,
  markers,
  activeId,
  onSelect,
  onMarkerChange,
  renderMarker,
  style: customStyle
}) {
  const store = useColorStore(), state = useColor(), ref = useRef(null), latest = useRef({ markers, activeId, onSelect, onMarkerChange });
  latest.current = { markers, activeId, onSelect, onMarkerChange };
  const multi = markers !== void 0;
  useEffect(
    () => multi ? bindMarkerWheel(ref.current, {
      getMarkers: () => latest.current.markers ?? [],
      getActiveId: () => latest.current.activeId ?? latest.current.markers?.[0]?.id ?? "",
      select: (id) => latest.current.onSelect?.(id),
      setHSV: (id, hsv) => latest.current.onMarkerChange?.(id, hsv)
    }) : bindColorArea(ref.current, store, "wheel"),
    [store, multi]
  );
  const css = (text) => Object.fromEntries(
    text.split(";").map((part) => {
      const i = part.indexOf(":");
      return [
        part.slice(0, i).replace(/-([a-z])/g, (_, c) => c.toUpperCase()),
        part.slice(i + 1)
      ];
    })
  );
  return /* @__PURE__ */ jsx(
    "div",
    {
      ref,
      "data-cp-part": "surface",
      className: `cp-wheel ${className} ${classes.root ?? ""}`,
      role: "group",
      tabIndex: 0,
      "aria-label": label,
      style: {
        ...css(multi ? markerWheelStyle() : wheelStyle(state)),
        ...customStyle
      },
      children: markers ? markers.map((marker) => /* @__PURE__ */ jsx(
        "button",
        {
          type: "button",
          "data-cp-part": "marker",
          "data-marker-id": marker.id,
          "data-small": markers.length === 1 || !marker.label ? "true" : void 0,
          className: `cp-wheel-marker ${classes.marker ?? ""}`,
          "aria-label": marker.ariaLabel ?? `Select ${marker.id} marker`,
          "aria-pressed": activeId === marker.id,
          style: css(markerStyle(marker, activeId === marker.id)),
          children: /* @__PURE__ */ jsx("span", { "data-cp-part": "marker-text", className: classes.text, children: renderMarker ? renderMarker(marker, activeId === marker.id) : marker.label })
        },
        marker.id
      )) : /* @__PURE__ */ jsx(
        "span",
        {
          "data-cp-part": "thumb",
          "aria-hidden": true,
          className: classes.thumb,
          style: css(wheelThumbStyle(state)),
          children: /* @__PURE__ */ jsx("span", { "data-cp-part": "thumb-text", className: classes.text, children: thumbText })
        }
      )
    }
  );
}
function ColorViewSelect({
  label = "Picker view",
  className = ""
}) {
  const store = useColorStore(), state = useColor();
  return /* @__PURE__ */ jsxs("label", { className: `cp-format ${className}`, children: [
    label,
    /* @__PURE__ */ jsx(
      "select",
      {
        "data-cp-part": "select",
        value: state.view,
        onChange: (e) => store.setView(e.target.value),
        children: colorViews.map((view) => /* @__PURE__ */ jsx("option", { value: view, children: view === "area" ? "Rectangle" : "Wheel" }, view))
      }
    )
  ] });
}
function ColorSurface() {
  const state = useColor();
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    state.view === "wheel" ? /* @__PURE__ */ jsx(ColorWheel, {}) : /* @__PURE__ */ jsx(ColorArea, {}),
    /* @__PURE__ */ jsx(ColorSlider, { channel: state.view === "wheel" ? "v" : "h" })
  ] });
}
function ColorAlphaInput({
  label = "Alpha",
  className = "",
  classes = {}
}) {
  const store = useColorStore(), ref = useRef(null);
  useEffect(() => bindAlphaInput(ref.current, store), [store]);
  return /* @__PURE__ */ jsxs(
    "label",
    {
      className: `cp-alpha-input cp-channel ${className} ${classes.root ?? ""} ${classes.label ?? ""}`,
      "data-cp-part": "alpha-input",
      children: [
        label,
        /* @__PURE__ */ jsxs("span", { className: "cp-channel-field", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              ref,
              "data-cp-part": "input",
              className: classes.input,
              type: "number",
              min: 0,
              max: 100,
              step: 0.1,
              defaultValue: store.getSnapshot().alpha * 100,
              "aria-label": label
            }
          ),
          /* @__PURE__ */ jsx("span", { children: "%" })
        ] })
      ]
    }
  );
}
export {
  ColorAlphaInput,
  ColorArea,
  ColorChannelInput,
  ColorFormatSelect,
  ColorInput,
  ColorMode,
  ColorPreview,
  ColorProvider,
  ColorSlider,
  ColorSurface,
  ColorSwatch,
  ColorTextInput,
  ColorViewSelect,
  ColorWheel,
  useColor,
  useColorStore
};
//# sourceMappingURL=index.js.map
