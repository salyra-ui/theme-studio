export * from '@sebytza23/color-picker';
import { type ReactNode, type CSSProperties } from 'react';
import { type ColorView, type ColorMarker, type ColorPartClasses, type SliderChannel, type HSV, type ChannelFormat, type ChannelIndex, type ColorFormat, type ColorStore } from '@sebytza23/color-picker';
export declare function useColorStore(): ColorStore;
export declare function useColor(): import("@sebytza23/color-picker-react").ColorSnapshot;
export declare function ColorProvider({ value, view, onChange, children, disabled, store: provided, }: {
    value?: string;
    disabled?: boolean;
    view?: ColorView;
    onChange?: (hex: string) => void;
    children: ReactNode;
    store?: ColorStore;
}): import("react").JSX.Element;
export declare function ColorArea({ className, style, classes, thumbText, renderThumb, label, }: {
    className?: string;
    style?: CSSProperties;
    classes?: ColorPartClasses;
    thumbText?: ReactNode;
    renderThumb?: (state: ReturnType<ColorStore['getSnapshot']>) => ReactNode;
    label?: string;
}): import("react").JSX.Element;
export declare function ColorSlider({ channel, label, className, classes, }: {
    channel?: SliderChannel;
    label?: string;
    className?: string;
    classes?: ColorPartClasses;
}): import("react").JSX.Element;
export declare function ColorTextInput({ format: override, label, className, classes, }: {
    format?: ColorFormat;
    label?: string;
    className?: string;
    classes?: ColorPartClasses;
}): import("react").JSX.Element;
export declare function ColorSwatch({ value, label, className, }: {
    value: string;
    label?: string;
    className?: string;
}): import("react").JSX.Element;
export declare function ColorPreview({ className }: {
    className?: string;
}): import("react").JSX.Element;
export declare function ColorMode({ className, children, }: {
    className?: string;
    children?: ReactNode | ((format: ColorFormat) => ReactNode);
}): import("react").JSX.Element;
export declare function ColorFormatSelect({ label, className, }: {
    label?: string;
    className?: string;
}): import("react").JSX.Element;
export declare function ColorChannelInput({ format, index, className, classes, }: {
    format: ChannelFormat;
    index: ChannelIndex;
    className?: string;
    classes?: ColorPartClasses;
}): import("react").JSX.Element;
export declare function ColorInput({ format: override, label, className, classes, }: {
    format?: ColorFormat;
    label?: string;
    className?: string;
    classes?: ColorPartClasses;
}): import("react").JSX.Element;
/** Hue/saturation wheel; pair with ColorSlider channel="v" for brightness. */
export declare function ColorWheel({ className, label, classes, thumbText, markers, activeId, onSelect, onMarkerChange, renderMarker, style: customStyle, }: {
    className?: string;
    label?: string;
    classes?: ColorPartClasses;
    thumbText?: ReactNode;
    markers?: readonly ColorMarker[];
    activeId?: string;
    onSelect?: (id: string) => void;
    onMarkerChange?: (id: string, hsv: Partial<HSV>) => void;
    renderMarker?: (marker: ColorMarker, active: boolean) => ReactNode;
    style?: CSSProperties;
}): import("react").JSX.Element;
export declare function ColorViewSelect({ label, className, }: {
    label?: string;
    className?: string;
}): import("react").JSX.Element;
export declare function ColorSurface(): import("react").JSX.Element;
export declare function ColorAlphaInput({ label, className, classes, }: {
    label?: string;
    className?: string;
    classes?: ColorPartClasses;
}): import("react").JSX.Element;
