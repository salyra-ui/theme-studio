import type { ColorStore, ColorSnapshot } from './picker.js';
export interface ColorPartClasses {
    root?: string;
    thumb?: string;
    marker?: string;
    text?: string;
    label?: string;
    track?: string;
    input?: string;
}
export type SliderChannel = 'h' | 's' | 'v' | 'alpha';
export declare const sliderLabels: {
    h: string;
    s: string;
    v: string;
    alpha: string;
};
export declare const sliderValue: (state: ColorSnapshot, channel: SliderChannel) => number;
export declare function setSliderValue(store: ColorStore, channel: SliderChannel, value: number): void;
export declare const alphaTrackStyle: (hex: string) => string;
/** Numeric alpha editor in percent; keeps a draft while editing and validates without clamping. */
export declare function bindAlphaInput(input: HTMLInputElement, store: ColorStore): () => void;
