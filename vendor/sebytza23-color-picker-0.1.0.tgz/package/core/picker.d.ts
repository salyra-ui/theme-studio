import { type ColorFormat, type HSV } from './color.js';
import { type ColorInfo, type ColorValues } from './values.js';
export interface ColorSnapshot extends Readonly<HSV> {
    /** Opaque RGB base. Use value for the RGBA hex result. */
    readonly hex: string;
    readonly value: string;
    readonly alpha: number;
    readonly format: ColorFormat;
    readonly view: ColorView;
    readonly disabled: boolean;
}
export declare const colorViews: readonly ["area", "wheel"];
export type ColorView = (typeof colorViews)[number];
export interface ColorStore {
    getColor(): ColorInfo;
    getValue<F extends ColorFormat>(format: F): ColorValues[F];
    getSnapshot(): ColorSnapshot;
    getServerSnapshot(): ColorSnapshot;
    subscribe(listener: () => void): () => void;
    setDisabled(disabled: boolean): void;
    setHex(hex: string): void;
    setFormat(format: ColorFormat): void;
    setView(view: ColorView): void;
    setAlpha(alpha: number): void;
    setHSV(hsv: Partial<HSV>): void;
}
export declare function createColorStore(hex?: string, format?: ColorFormat, view?: ColorView, disabled?: boolean): ColorStore;
/** Shared controller for pointer capture, touch, keyboard and frame batching. DOM access is mount-only. */
export declare function bindColorArea(element: HTMLElement, store: ColorStore, mode?: 'area' | 'wheel'): () => void;
export declare function wheelAtPoint(state: HSV, x: number, y: number, width: number, height: number): HSV;
export declare function wheelStyle(state: HSV): string;
export declare function wheelThumbStyle(state: HSV): string;
export declare function areaStyle(state: ColorSnapshot): string;
export declare function thumbStyle(state: ColorSnapshot): string;
/** Subscribe only to actual color changes, not format or achromatic hue changes. */
export declare function subscribeColor(store: ColorStore, onChange: (hex: string) => void): () => void;
