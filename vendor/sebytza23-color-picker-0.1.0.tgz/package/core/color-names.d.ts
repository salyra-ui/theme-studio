export declare const colorNames: readonly (readonly [string, string])[];
