import type { HSV } from './color.js';
export interface ColorMarker {
    readonly id: string;
    readonly color: Readonly<HSV & {
        hex: string;
    }>;
    readonly label?: string;
    readonly ariaLabel?: string;
}
export interface MarkerWheelOptions {
    getMarkers(): readonly ColorMarker[];
    getActiveId(): string;
    select(id: string): void;
    setHSV(id: string, hsv: Partial<HSV>): void;
}
export declare const markerWheelStyle: () => string;
export declare function markerStyle(marker: ColorMarker, active: boolean): string;
/** Each queued drag sample retains its role, even if selection changes before the frame. */
export declare function bindMarkerWheel(element: HTMLElement, options: MarkerWheelOptions): () => void;
