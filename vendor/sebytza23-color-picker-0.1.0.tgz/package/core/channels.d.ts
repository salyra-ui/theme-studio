import { type ColorFormat } from './color.js';
import type { ColorStore, ColorSnapshot } from './picker.js';
export type ChannelIndex = 0 | 1 | 2;
export type ChannelFormat = Exclude<ColorFormat, 'hex'>;
export interface ChannelSpec {
    label: string;
    min: number;
    max: number;
    step: number;
    unit: string;
}
export declare const channelSpecs: Record<ChannelFormat, readonly [ChannelSpec, ChannelSpec, ChannelSpec]>;
export declare function getColorChannels(state: ColorSnapshot, format: ChannelFormat): [number, number, number];
export declare function channelValue(state: ColorSnapshot, format: ChannelFormat, index: ChannelIndex): string;
export declare function setColorChannel(store: ColorStore, format: ChannelFormat, index: ChannelIndex, value: number): void;
