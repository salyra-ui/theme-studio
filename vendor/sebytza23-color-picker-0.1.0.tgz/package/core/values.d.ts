import { type ColorFormat, type HSV } from './color.js';
import { type OKLab, type OKLCH } from './oklab.js';
export interface ColorValues {
    readonly hex: string;
    readonly alpha: number;
    readonly rgb: Readonly<{
        r: number;
        g: number;
        b: number;
        alpha: number;
    }>;
    readonly hsl: Readonly<{
        h: number;
        s: number;
        l: number;
        alpha: number;
    }>;
    readonly hsv: Readonly<HSV & {
        alpha: number;
    }>;
    /** L is 0–1; C and hue in degrees use native OKLCH units. */
    readonly oklch: Readonly<OKLCH & {
        alpha: number;
    }>;
    readonly oklab: Readonly<OKLab & {
        alpha: number;
    }>;
}
export interface ColorNameMatch {
    readonly name: string;
    readonly slug: string;
    readonly matchedHex: string;
    readonly exact: boolean;
}
export interface ColorInfo extends ColorValues, ColorNameMatch {
    /** Formatted channel strings; wrap hsl/oklch/etc in their CSS function when needed. HSV is not CSS. */
    readonly formats: Readonly<Record<ColorFormat, string>>;
}
export declare function getColorNameMatch(input: string): ColorNameMatch;
export declare const getColorName: (hex: string) => string;
/** Numeric values are requested independently; requesting HEX never performs naming or Lab work. */
export declare function getColorValue<F extends ColorFormat>(input: string, format: F, alpha?: number): ColorValues[F];
export declare function getColor(hex: string, alpha?: number): ColorInfo;
