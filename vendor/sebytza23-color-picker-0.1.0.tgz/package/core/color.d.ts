import { type OKLCH } from './oklab.js';
export interface HSV {
    h: number;
    s: number;
    v: number;
}
export declare const clamp: (n: number, min?: number, max?: number) => number;
export declare const hue: (h: number) => number;
export declare function normalizeHex(input: string): string;
/** RGBA hex input; alpha is last, matching CSS #RGBA/#RRGGBBAA. */
export declare function normalizeColorHex(input: string): string;
export declare const opaqueHex: (input: string) => string;
export declare function hexAlpha(input: string): number;
export declare function withAlpha(input: string, alpha: number): string;
export declare function hexToRgb(input: string): [number, number, number];
export declare function hsvToHex({ h, s, v }: HSV): string;
export declare function hexToHsv(input: string, previousHue?: number): HSV;
export declare function hsvToChannels({ h, s, v }: HSV): string;
export declare function channelsToHex(channels: string): string;
export declare function luminance(hex: string): number;
export declare function contrast(a: string, b: string): number;
export declare function foreground(hex: string): string;
/** Constant work and memory regardless of picker size. */
export declare function colorAtPoint(h: number, x: number, y: number, width: number, height: number): HSV;
export declare const colorFormats: readonly ["hex", "rgb", "hsl", "hsv", "oklch", "oklab"];
export type ColorFormat = (typeof colorFormats)[number];
export declare function hexToOklch(hex: string): OKLCH;
export declare function oklchToHex(color: OKLCH): string;
export declare function rgbToHex(rgb: readonly [number, number, number]): string;
export declare function parseColor(text: string, format?: ColorFormat): string;
export declare function formatColor(input: string, format?: ColorFormat, alpha?: number): string;
