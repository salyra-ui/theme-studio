/** Oklab matrices: https://bottosson.github.io/posts/oklab/ (D65, linear sRGB). */
export interface OKLab {
    l: number;
    a: number;
    b: number;
}
export interface OKLCH {
    l: number;
    c: number;
    h: number;
}
export declare function rgbToOklab(rgb: readonly number[]): OKLab;
export declare function oklabToOklch({ l, a, b }: OKLab): OKLCH;
export declare function oklchToOklab({ l, c, h }: OKLCH): OKLab;
/** Map out-of-sRGB colors by reducing chroma, preserving lightness and hue. */
export declare function oklchToRgb(color: OKLCH): [number, number, number];
export declare function oklabToRgb(color: OKLab): [number, number, number];
